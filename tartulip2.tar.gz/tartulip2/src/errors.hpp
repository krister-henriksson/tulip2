

#ifndef ERRORS_HPP
#define ERRORS_HPP



#include <exception>

#include <cstdlib>


class bad_mds : public std::exception { } ;
// MD relaxation failed with e.g. infinite temperature.









#endif


